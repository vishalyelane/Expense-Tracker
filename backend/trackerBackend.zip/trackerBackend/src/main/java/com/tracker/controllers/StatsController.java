package com.tracker.controllers;

import com.tracker.repositories.UserRepository;
import com.tracker.repositories.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/stats")
public class StatsController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ExpenseRepository expenseRepository;

    @GetMapping("/counts")
    public Map<String, Long> getCounts() {
        long userCount = userRepository.count();
        long expenseCount = expenseRepository.count();

        return Map.of(
            "users", userCount,
            "expenses", expenseCount
        );
    }
}
