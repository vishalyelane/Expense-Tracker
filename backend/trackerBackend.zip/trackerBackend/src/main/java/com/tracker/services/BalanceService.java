package com.tracker.services;

public interface BalanceService {
  
	double totalbalance();
}
