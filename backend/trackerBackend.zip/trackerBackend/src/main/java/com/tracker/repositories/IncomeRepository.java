package com.tracker.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.tracker.models.Income;

public interface IncomeRepository extends JpaRepository<Income, String>,PagingAndSortingRepository<Income, String> {

	List<Income> findByTitleStartingWithIgnoreCase (String prefix);
	
}
