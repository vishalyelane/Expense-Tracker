package com.tracker.controllers;


import lombok.RequiredArgsConstructor;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.web.bind.annotation.*;

import com.tracker.Auth.AuthRequest;
import com.tracker.Auth.AuthResponse;
import com.tracker.Auth.RegisterRequest;
import com.tracker.models.User;
import com.tracker.services.JwtService;
import com.tracker.services.UserService;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:4200")

public class AuthController {

    private final AuthenticationManager authManager;
    private final UserService userService;
    private final JwtService jwtService;

    @Autowired
    public AuthController(AuthenticationManager authManager, UserService userService, JwtService jwtService) {
        this.authManager = authManager;
        this.userService = userService;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public String register(@RequestBody RegisterRequest request) {
    	User user = new User(null, request.getUsername(), request.getPassword());
        userService.register(user);
        return "User registered successfully!";
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request) {
        AuthResponse response = new AuthResponse("dummy-token-12345");
        return ResponseEntity.ok(response);
    }
    
    

}