package com.tracker.responsewrappers;

import lombok.Data;

@Data
public class IncomeApiResponseEntity {
   
	
	String message;
	Object data;
}
